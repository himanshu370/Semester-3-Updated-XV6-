//A C program to test working of xv6

#include "types.h"
#include "stat.h"
#include "user.h"

// passing command line arguments

int main(int argc, char *argv[])
{
	printf(1, "A test program to show working of xv6\n");
	exit();
}
